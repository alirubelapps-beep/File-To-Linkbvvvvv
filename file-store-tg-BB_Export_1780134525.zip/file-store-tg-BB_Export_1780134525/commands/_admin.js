/*CMD
  command: /admin
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admin = Bot.getProperty("admin")
var firebase_url = `FIREBASE_URL`
var chat_id = "CHANNEL_CHATID" 

if (!admin) {
  Bot.setProperty("admin", user.telegramid, "integer")
  Bot.setProperty("chat_id", chat_id, "integer")
  Bot.setProperty("firebase_url", firebase_url, "string")
  Bot.sendMessage("*All Set Successfully ✅*", {
    is_reply: true,
    parse_mode: "Markdown"
  })
}

