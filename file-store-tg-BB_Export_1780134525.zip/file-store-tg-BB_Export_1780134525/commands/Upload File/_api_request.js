/*CMD
  command: /api_request
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Upload File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let msg_id = request.message_id;
var flex = Bot.getProperty("chat_id")
HTTP.post({
  url: "https://api.telegram.org/bot" + bot.token + "/copyMessage",
  body: JSON.stringify({
    chat_id: flex,
    from_chat_id: chat.chatid,
    message_id: msg_id
  }),
  success: "/add_db"
});

