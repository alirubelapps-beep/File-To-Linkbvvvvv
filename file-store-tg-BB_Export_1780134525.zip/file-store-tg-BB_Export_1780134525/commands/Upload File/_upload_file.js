/*CMD
  command: /upload_file
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Upload File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]]
var id = User.getProperty("private")

Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `<b>Enter title for file 👇</b>`,
  parse_mode: "html",
  reply_markup: { inline_keyboard: but }
})

Bot.runCommand("/send_file")
