/*CMD
  command: /add_db
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Upload File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var flex = JSON.parse(content);  
var msg_id = flex.result.message_id 
var filename = User.getProperty("filename")
var flex = Bot.getProperty("firebase_url")
var randmid = Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
var id = `flex_${randmid}`
User.setProperty("file_token",id,"string")
HTTP.post({
  url: `${flex}/user/${chat.chatid}/files/${filename}.json`,
  headers: {
    "X-HTTP-Method-Override": "PUT"
  },
 body: JSON.stringify({
    token: id,
    message_id: msg_id
  }), 
 success:"/saved_data"
});

