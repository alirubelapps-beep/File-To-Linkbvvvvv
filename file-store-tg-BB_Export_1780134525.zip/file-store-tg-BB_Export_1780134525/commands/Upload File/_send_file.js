/*CMD
  command: /send_file
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Upload File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]]
var id = User.getProperty("private")
var flex = message.trim()
if (flex.length >= 20) {
  Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `<b>⚠️ Title should be short, Send again!!</b>`,
  parse_mode: "html",
  reply_markup: { inline_keyboard: but }
})
  Bot.runCommand("/send_file")
  return
}
User.setProperty("filename",encodeURIComponent(flex),"string")

Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `<b>Send any type of message or files 👇</b>`,
  parse_mode: "html",
  reply_markup: { inline_keyboard: but }
})

Bot.runCommand("/api_request")
