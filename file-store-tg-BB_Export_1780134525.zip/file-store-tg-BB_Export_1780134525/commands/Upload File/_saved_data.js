/*CMD
  command: /saved_data
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Upload File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]]
var id = User.getProperty("private")
var filename = decodeURIComponent(User.getProperty("filename"))
var flex = User.getProperty("file_token")

Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `<b>Add file In DB ✅</b>
  
<blockquote><b>File Info</b></blockquote>
<b>📂 File Name: </b> ${filename}
<b>🗝️ File ID: </b> <code>${flex}</code>`,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: but }
})
User.setProperty("filename",null)
User.setProperty("file_token",null)
