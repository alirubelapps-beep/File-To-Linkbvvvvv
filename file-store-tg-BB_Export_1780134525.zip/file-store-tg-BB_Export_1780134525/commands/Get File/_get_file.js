/*CMD
  command: /get_file
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Get File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]]
var id = User.getProperty("private")

Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `<b>Send the File ID of the file you want to retrieve 👇</b>`,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: but }
})

Bot.runCommand("/get_fileinfo")
