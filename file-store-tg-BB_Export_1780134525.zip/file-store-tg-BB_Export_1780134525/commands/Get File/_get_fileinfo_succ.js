/*CMD
  command: /get_fileinfo_succ
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Get File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var flex = JSON.parse(content);
var admins = Bot.getProperty("admin")
var msg = User.getProperty("file_info");
var chats = Bot.getProperty("chat_id");
var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]];
var support = [[{ text: "📞 Support Chat", url: `tg://user?id=${admins}` }]];
var id = User.getProperty("private");
var fileData = null;
if (flex == null) {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: `❌ File not found`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }] ]
    }
  });
  return;
} 
var keys = Object.keys(flex);
for (var i = 0; i < keys.length; i++) {
  if (flex[keys[i]].token == msg) {
    fileData = flex[keys[i]];
    break;
  }
} 
if (fileData) {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: `<b>File content shared successfully ✅</b>`,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: but }
  });
  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/copyMessage",
    body: JSON.stringify({
      chat_id: user.telegramid,
      from_chat_id: chats,
      message_id: fileData.message_id,
      reply_markup: JSON.stringify({
      inline_keyboard: support
    })
    }),
    headers: { "Content-Type": "application/json" }
  });
  User.setProperty("file_info", null);
} else {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: `<b>😔 Shared file id is invalid, send again !!</b>`,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: but }
  });
  User.setProperty("file_info", null,);
  Bot.runCommand("/get_fileinfo");
}
