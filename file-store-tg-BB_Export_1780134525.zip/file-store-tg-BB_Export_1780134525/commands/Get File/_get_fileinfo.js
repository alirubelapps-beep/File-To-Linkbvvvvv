/*CMD
  command: /get_fileinfo
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Get File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var flex = Bot.getProperty("firebase_url");
var url = `${flex}/user/${chat.chatid}/files.json`;
var msg = message;
User.setProperty("file_info", msg, "string");
HTTP.get({
  url: url,
  success: "/get_fileinfo_succ"
});
