/*CMD
  command: /start
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admins = Bot.getProperty("admin")
if (!admins) return Bot.sendMessage("*⚠️ Add Info First !!*",{is_reply:true, parse_mode:"Markdown"}) 
var id = User.getProperty("private")

var txt =
  `<b>👋 Hey <a href="tg://user?id=${user.telegramid}">${user.first_name}</a></b>

I store and organize your files so you don’t lose them.

• Photos  
• Videos  
• Documents  
• Any file type

Send anything here and I’ll keep it saved for you with quick access whenever you need it.

<blockquote><b>⚡ Just send a file and it’s stored.</b></blockquote>`
var but = [
  [
    { text: "➕ Upload Files ➕", callback_data: `/upload_file` },
    { text: "📂 Get Files 📂", callback_data: `/get_file` }
  ],
  [
    { text: "👁️ View File", callback_data: `/show_file` },
    { text: "🗑️ Delete File", callback_data: `/delete_file` }
   
  ],
  [
    { text: "📞 Support Chat", url: `tg://user?id=${admins}` }
  ]
]


if (!User.getProperty("UserDone")) {
  User.setProperty("UserDone", true, "boolean");
  Libs.ResourcesLib.anotherChatRes("status", "global").add(1);

  Api.sendMessage({
    chat_id: admins,
    text:
      "➕ <b>New User Notification</b> ➕\n\n👤<b>User:</b> <a href='tg://user?id=" +
      user.telegramid +
      "'>" +
      user.first_name +
      "</a>\n\n🆔<b> User ID :</b> <code>" +
      user.telegramid +
      "</code>\n\n🌝 <b>Total User's Count: " +
      Libs.ResourcesLib.anotherChatRes("status", "global").value() +
      "</b>",
    parse_mode: "html",
    disable_web_page_preview: true
  });
}


if (request.message_id) {
  Api.sendMessage({
    text: txt,
    parse_mode: "html",
    disable_web_page_preview: true,
    on_result: "/private",
    reply_to_message_id: request.message_id, 
   reply_markup: {
      inline_keyboard: but
    }
  })
} else {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: txt,
    parse_mode: "html",
    reply_markup: { inline_keyboard: but }
  })

  return
}



