/*CMD
  command: /delete_file
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Delete File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]]
var id = User.getProperty("private")

Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `<b>Send file id which you wanna delete 👇</b>`,
  parse_mode: "html",
  reply_markup: { inline_keyboard: but }
})

Bot.runCommand("/delete_file_api")
