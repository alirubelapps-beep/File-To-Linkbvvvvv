/*CMD
  command: /delete_check
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Delete File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var input = User.getProperty("delete_target");
var id = User.getProperty("private");
var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]];
var data = JSON.parse(content);
var matchedFilename = null;
if (data == null) {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: `❌ File not found`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }] ]
    }
  });
  return;
} 
var keys = Object.keys(data);
for (var i = 0; i < keys.length; i++) {
  if (data[keys[i]].token === input) {
    matchedFilename = keys[i];
    break;
  }
}

if (!matchedFilename) {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: `❌ File not found, send correct token!!`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "🔄 Try Again", callback_data: "/delete_file" }],[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]]
    }
  });
  return;
}

User.setProperty("delete_target", matchedFilename, "string");
User.setProperty("delete_msg_id", data[matchedFilename].message_id, "integer");

var baseUrl = Bot.getProperty("firebase_url");
var url = `${baseUrl}/user/${chat.chatid}/files.json`;
var body = {};
body[matchedFilename] = null;

HTTP.post({
  url: url + "?x-http-method-override=PATCH",
  body: JSON.stringify(body),
  headers: { "Content-Type": "application/json" }, 
  success:"/delete_success"
});

