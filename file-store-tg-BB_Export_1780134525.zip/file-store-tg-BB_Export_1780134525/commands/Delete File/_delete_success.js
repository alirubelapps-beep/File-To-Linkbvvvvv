/*CMD
  command: /delete_success
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Delete File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var filename = User.getProperty("delete_target");
var deletedMsgId = User.getProperty("delete_msg_id");
var id = User.getProperty("private");
var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]];

Api.deleteMessage({
  chat_id: user.telegramid,
  message_id: deletedMsgId
});

Api.editMessageText({
  chat_id: user.telegramid,
  message_id: id,
  text: `✅ File <b>${filename}</b> deleted successfully.`,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: but }
});

User.setProperty("delete_target", null);
User.setProperty("delete_msg_id", null);
