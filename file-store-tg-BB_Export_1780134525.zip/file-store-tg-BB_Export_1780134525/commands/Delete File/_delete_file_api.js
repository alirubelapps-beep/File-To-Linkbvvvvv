/*CMD
  command: /delete_file_api
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Delete File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var baseUrl = Bot.getProperty("firebase_url");
var url = `${baseUrl}/user/${chat.chatid}/files.json`;
var filename = message.trim();

User.setProperty("delete_target", filename, "string");

HTTP.get({
  url: url,
  success: "/delete_check",
});
