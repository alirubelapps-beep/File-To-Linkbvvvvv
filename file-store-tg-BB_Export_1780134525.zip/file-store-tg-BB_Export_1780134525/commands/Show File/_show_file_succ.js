/*CMD
  command: /show_file_succ
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Show File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var flex = JSON.parse(content);
var but = [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }]];
var text = `<blockquote><b>List of file id 👇</b></blockquote>\n\n`;
var id = User.getProperty("private");

if (flex == null) {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: `❌ File not found`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "⬅️ Bᴀᴄᴋ", callback_data: "/start" }] ]
    }
  });
  return;
} 
var keys = Object.keys(flex);
for (var i = 0; i < keys.length; i++) {
  var filename = keys[i];
  var filetoken = flex[filename].token;
  text += `<b>${filename} :</b> <code>${filetoken}</code>\n\n`;
}

var LIMIT = 4096;

if (text.length > LIMIT) {
  var mid = Math.floor(text.length / 2);
  var splitIndex = text.lastIndexOf("\n\n", mid);
  if (splitIndex === -1) splitIndex = mid;
  var part1 = text.substring(0, splitIndex);
  var part2 = text.substring(splitIndex).trim();

  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: part1,
    parse_mode: "HTML"
  });

  Api.sendMessage({
    chat_id: user.telegramid,
    text: part2,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: but }
  });

} else {
  Api.editMessageText({
    chat_id: user.telegramid,
    message_id: id,
    text: text,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: but }
  });
}
