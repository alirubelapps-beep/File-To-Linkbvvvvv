/*CMD
  command: /show_file
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Show File

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var flex = Bot.getProperty("firebase_url");
var url = `${flex}/user/${chat.chatid}/files.json`;

HTTP.get({
  url: url,
  success: "/show_file_succ"
});
