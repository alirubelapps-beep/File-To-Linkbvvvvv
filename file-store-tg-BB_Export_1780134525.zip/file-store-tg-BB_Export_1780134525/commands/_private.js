/*CMD
  command: /private
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let flex_coder = options.result.message_id
User.setProperty("private", flex_coder, "integer")

